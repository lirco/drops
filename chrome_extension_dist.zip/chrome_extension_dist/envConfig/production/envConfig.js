"use strict";

 angular.module('envConfig', [])

.constant('ENV', {name:'production',apiEndPoint:'https://www.clipto.co'})

;
